name = "RedPy"
from RedPy.redpy import Redpy
